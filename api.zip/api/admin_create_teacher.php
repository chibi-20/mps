<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_login('admin');
verify_csrf();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed.'); }

$raw = json_decode(file_get_contents('php://input'), true) ?? [];
$last = validate_string($raw['last_name'] ?? '', 100);
$first = validate_string($raw['first_name'] ?? '', 100);
$middle = validate_string($raw['middle_name'] ?? '', 100);
$username = validate_string($raw['username'] ?? '', 50);
$password = (string)($raw['password'] ?? '');
$grades = array_values(array_unique(array_filter(array_map('intval', (array)($raw['grade_levels'] ?? [])),
    fn($grade) => in_array($grade, AVAILABLE_GRADE_LEVELS, true))));
$subjects = array_values(array_unique(array_filter((array)($raw['subjects'] ?? []),
    fn($subject) => is_string($subject) && in_array($subject, AVAILABLE_SUBJECTS, true))));

if ($last === '' || $first === '' || $username === '' || !preg_match('/^[A-Za-z0-9._-]{3,50}$/', $username)) {
    json_response(['error' => 'Enter a first name, last name, and valid username (3–50 letters, numbers, dots, underscores, or hyphens).'], 422);
}
if (mb_strlen($password) < 8) json_response(['error' => 'Temporary password must be at least 8 characters.'], 422);
if (!$grades || !$subjects) json_response(['error' => 'Select at least one grade level and one subject.'], 422);

$pdo = get_pdo();
$check = $pdo->prepare('SELECT id FROM users WHERE username = ?');
$check->execute([$username]);
if ($check->fetch()) json_response(['error' => 'That username is already taken.'], 409);

$pdo->beginTransaction();
try {
    $pdo->prepare("INSERT INTO users (last_name, first_name, middle_name, username, password_hash, role, is_active, must_change_password)
        VALUES (?,?,?,?,?,'teacher',1,1)")->execute([$last, $first, $middle !== '' ? $middle : null, $username, password_hash($password, PASSWORD_DEFAULT)]);
    $teacherId = (int)$pdo->lastInsertId();
    $gradeInsert = $pdo->prepare('INSERT INTO user_grade_levels (user_id, grade_level) VALUES (?,?)');
    foreach ($grades as $grade) $gradeInsert->execute([$teacherId, $grade]);
    $subjectInsert = $pdo->prepare('INSERT INTO user_subjects (user_id, subject_name) VALUES (?,?)');
    foreach ($subjects as $subject) $subjectInsert->execute([$teacherId, $subject]);
    $pdo->commit();
    json_response(['success' => true, 'teacher_id' => $teacherId]);
} catch (Throwable $e) {
    $pdo->rollBack();
    json_response(['error' => 'Could not create teacher account.'], 500);
}
