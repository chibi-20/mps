(() => {
    const page = window.studentPageData;
    if (!page) return;
    const $ = (id) => document.getElementById(id);
    const modal = $('studentModal');
    const sectionSelect = $('studentSection');
    const notice = $('studentNotice');
    let importFile = null;
    const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
    window.filterStudentSections = (selected = '') => {
        const gradeId = $('studentGrade').value;
        const choices = page.sections.filter((section) => Number(section.grade_level_id) === Number(gradeId) && Number(section.school_year_id) === Number(page.schoolYearId));
        sectionSelect.innerHTML = '<option value="">Unassigned</option>' + choices.map((section) => `<option value="${section.id}">${escapeHtml(section.name)}</option>`).join('');
        sectionSelect.value = String(selected || '');
    };
    window.openStudentForm = (student = {}) => {
        $('studentFormError').textContent = '';
        $('studentModalTitle').textContent = student.id ? 'Edit Student' : 'Add Student';
        $('studentId').value = student.id || '';
        $('studentLrn').value = student.lrn || '';
        $('studentName').value = student.name || '';
        $('studentSex').value = student.sex || '';
        $('studentGrade').value = student.grade || '';
        filterStudentSections(student.section || '');
        modal.style.display = '';
    };
    window.closeStudentForm = () => { modal.style.display = 'none'; };
    window.editStudent = (button) => {
        const row = button.closest('tr');
        openStudentForm({id:row.dataset.studentId,lrn:row.dataset.lrn,name:row.dataset.name,sex:row.dataset.sex,grade:row.dataset.grade,section:row.dataset.section});
    };
    window.saveStudent = async () => {
        const payload = {id:$('studentId').value || null,lrn:$('studentLrn').value.trim(),name:$('studentName').value.trim(),sex:$('studentSex').value,grade_level_id:$('studentGrade').value || null,section_id:sectionSelect.value || null,school_year_id:page.schoolYearId,csrf_token:page.csrf};
        const response = await fetch('api/admin_save_student.php',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':page.csrf},body:JSON.stringify(payload)});
        const result = await response.json();
        if (!response.ok || result.error) {$('studentFormError').textContent=result.error || 'Could not save student.';return;}
        window.location.reload();
    };
    window.importStudents = (input) => {
        if (!input.files.length) return;
        importFile = input.files[0];
        $('importError').textContent = '';
        if (page.isAdmin) { $('importGrade').value = ''; filterImportSections(); }
        else {
            $('importSection').innerHTML = '<option value="">Select section</option>' + page.sections.filter((section)=>Number(section.school_year_id)===Number(page.schoolYearId)).map((section)=>`<option value="${section.id}">Grade ${section.level} · ${escapeHtml(section.name)}</option>`).join('');
        }
        $('studentImportOptions').style.display = '';
    };
    window.filterImportSections = () => {
        const gradeId = $('importGrade').value;
        const sections = page.sections.filter((section)=>Number(section.grade_level_id)===Number(gradeId)&&Number(section.school_year_id)===Number(page.schoolYearId));
        $('importSection').innerHTML = '<option value="">Select section</option>' + sections.map((section)=>`<option value="${section.id}">${escapeHtml(section.name)}</option>`).join('');
        $('importSection').disabled = !gradeId;
    };
    window.cancelStudentImport = () => { importFile=null; $('studentImportOptions').style.display='none'; $('studentImportFile').value=''; };
    window.confirmStudentImport = async () => {
        if (!importFile) return;
        const gradeId = page.isAdmin ? $('importGrade').value : '';
        const sectionId = $('importSection').value;
        if ((gradeId || !page.isAdmin) && !sectionId) {$('importError').textContent='Select a section before importing.';return;}
        const form = new FormData();
        form.append('file',importFile); form.append('school_year_id',page.schoolYearId); form.append('csrf_token',page.csrf);
        if (sectionId) { if (gradeId) form.append('grade_level_id',gradeId); form.append('section_id',sectionId); }
        const response=await fetch('api/import_students.php',{method:'POST',headers:{'X-CSRF-Token':page.csrf},body:form});
        const result=await response.json();
        if(!response.ok||result.error){$('importError').textContent=result.error||'Import failed.';return;}
        const errors=(result.errors||[]).join(' ');
        showNotice(`Imported ${result.imported} student row(s). ${result.error_count ? `${result.error_count} row(s) were skipped. ${errors}` : ''}`,'success');
        cancelStudentImport();
        if(result.imported) window.setTimeout(()=>window.location.reload(),1200);
    };
    function showNotice(message,type){notice.className=`alert alert-${type}`;notice.textContent=message;notice.style.display='';}
})();
