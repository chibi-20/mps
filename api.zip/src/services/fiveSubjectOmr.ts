import { detectCorners, project, type Corners, type Point } from "./omr";

export const TEMPLATE_WIDTH = 2550;
export const TEMPLATE_HEIGHT = 3300;
const OUTPUT_SCALE = 0.5;
const referenceCorners: Corners = [
  { x: 131, y: 131 },
  { x: 2419, y: 131 },
  { x: 2419, y: 3168 },
  { x: 131, y: 3168 },
];
const bubbleX = [244, 697, 1151, 1604, 2058];
const answerRowStartY = 720;
const answerRowSpacing = 47.7;
const answerChoiceSpacing = 74.5;

export function findSheetCorners(image: ImageData): Corners | null {
  return detectCorners(image);
}

export function rectifyFiveSubjectSheet(
  source: ImageData,
  corners: Corners,
): HTMLCanvasElement {
  const width = Math.round(TEMPLATE_WIDTH * OUTPUT_SCALE);
  const height = Math.round(TEMPLATE_HEIGHT * OUTPUT_SCALE);
  const inputScaleX = source.width / TEMPLATE_WIDTH;
  const inputScaleY = source.height / TEMPLATE_HEIGHT;
  const projectPoint = project(
    referenceCorners.map((p) => ({ x: p.x * inputScaleX, y: p.y * inputScaleY })) as Corners,
    corners,
  );
  const output = document.createElement("canvas");
  output.width = width;
  output.height = height;
  const ctx = output.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("This browser cannot process the answer sheet image.");
  const rectified = ctx.createImageData(width, height);
  for (let y = 0; y < height; y++) {
    const templateY = (y / OUTPUT_SCALE) * inputScaleY;
    for (let x = 0; x < width; x++) {
      const p = projectPoint({ x: (x / OUTPUT_SCALE) * inputScaleX, y: templateY });
      const sx = Math.round(p.x);
      const sy = Math.round(p.y);
      const dest = (y * width + x) * 4;
      if (sx < 0 || sy < 0 || sx >= source.width || sy >= source.height) {
        rectified.data[dest] = 255;
        rectified.data[dest + 1] = 255;
        rectified.data[dest + 2] = 255;
        rectified.data[dest + 3] = 255;
        continue;
      }
      const src = (sy * source.width + sx) * 4;
      rectified.data[dest] = source.data[src];
      rectified.data[dest + 1] = source.data[src + 1];
      rectified.data[dest + 2] = source.data[src + 2];
      rectified.data[dest + 3] = 255;
    }
  }
  ctx.putImageData(rectified, 0, 0);
  return output;
}

function bubbleFill(data: ImageData, center: Point): number {
  let dark = 0;
  let total = 0;
  const radius = 3.4;
  const threshold = 145;
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      if (dx * dx + dy * dy > radius * radius) continue;
      const x = Math.round(center.x + dx);
      const y = Math.round(center.y + dy);
      if (x < 0 || y < 0 || x >= data.width || y >= data.height) continue;
      const index = (y * data.width + x) * 4;
      const gray = data.data[index] * 0.299 + data.data[index + 1] * 0.587 + data.data[index + 2] * 0.114;
      total++;
      if (gray < threshold) dark++;
    }
  }
  return total ? dark / total : 0;
}

export interface BubbleAnswer {
  choice: "A" | "B" | "C" | "D" | null;
  status: "marked" | "blank" | "multiple" | "uncertain";
  confidence: number;
}

export function readFiveSubjectAnswers(rectified: HTMLCanvasElement): BubbleAnswer[][] {
  const ctx = rectified.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("This browser cannot read answer bubbles.");
  const image = ctx.getImageData(0, 0, rectified.width, rectified.height);
  return bubbleX.map((left) =>
    Array.from({ length: 50 }, (_, itemIndex) => {
      const scores = [0, 1, 2, 3].map((choice) =>
        bubbleFill(image, {
          x: (left + choice * answerChoiceSpacing) * OUTPUT_SCALE,
          y: (answerRowStartY + itemIndex * answerRowSpacing) * OUTPUT_SCALE,
        }),
      );
      const marked = scores.map((score, i) => ({ score, i })).filter((x) => x.score >= 0.38);
      const sorted = [...scores].sort((a, b) => b - a);
      if (marked.length > 1) return { choice: null, status: "multiple" as const, confidence: 0.15 };
      if (marked.length === 1 && sorted[0] - sorted[1] > 0.16) {
        return {
          choice: (['A', 'B', 'C', 'D'] as const)[marked[0].i],
          status: "marked" as const,
          confidence: Math.min(0.99, 0.65 + (sorted[0] - sorted[1]) * 0.4),
        };
      }
      if (sorted[0] > 0.22) return { choice: null, status: "uncertain" as const, confidence: 0.2 };
      return { choice: null, status: "blank" as const, confidence: 0.65 };
    }),
  );
}

export const studentBarcodeRegion = { x: 1730, y: 230, width: 590, height: 210 };
export function subjectBarcodeRegion(column: number) {
  return { x: 170 + column * 453, y: 480, width: 410, height: 190 };
}

export function parseStudentSectionBarcode(value: string | null) {
  const match = value?.match(/^([^_]+)_([^_]+)$/);
  if (!match) return { studentId: "", sectionId: "" };
  return { studentId: match[1].trim(), sectionId: match[2].trim() };
}

export function parseSubjectBarcode(value: string | null) {
  const match = value?.match(/^(\d+)_([^_]+)$/);
  if (!match) return { subjectId: "", studentId: "" };
  return { subjectId: match[1], studentId: match[2].trim() };
}
