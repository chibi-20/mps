import { BarcodeFormat, BrowserMultiFormatReader } from "@zxing/browser";
import { DecodeHintType } from "@zxing/library";

const scale = 0.5;

export function createBarcodeReader() {
  return new BrowserMultiFormatReader(new Map<DecodeHintType, unknown>([
    [DecodeHintType.POSSIBLE_FORMATS, [BarcodeFormat.CODE_128]],
    [DecodeHintType.TRY_HARDER, true],
  ]));
}

export function decodeBarcode(
  reader: BrowserMultiFormatReader,
  sheet: HTMLCanvasElement,
  region: { x: number; y: number; width: number; height: number },
): string | null {
  const crop = document.createElement("canvas");
  crop.width = region.width * scale;
  crop.height = region.height * scale;
  const ctx = crop.getContext("2d");
  if (!ctx) return null;
  ctx.drawImage(sheet, region.x * scale, region.y * scale, region.width * scale, region.height * scale, 0, 0, crop.width, crop.height);
  try { return reader.decodeFromCanvas(crop).getText().trim(); }
  catch { return null; }
}
